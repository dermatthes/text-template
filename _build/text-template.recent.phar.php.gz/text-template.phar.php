<?php

Phar::mapPhar('text-template');

require ("phar://text-template/TextTemplate.php");


__HALT_COMPILER(); ?>
�                  	   README.md�  ��U�  ���9�         TextTemplate.phpb+  ��Ub+  �����         LICENSEM  ��UM  ?|϶      # Text-Template
Single-Class PHP5 template engine with support for if/loops/filters

It is aimed to be a small string Template-Engine to meet e-Mailing or small html-Template demands. It is not meant
to be a replacement for pre-compiled full featured Template-Engines like Smarty or Twig.

TextTemplate uses Regular-Expressions for text-Parsing. No code is generated or evaluated - so this might
be a secure solution to use in no time-critical situations.

Whilst most template-engines rely on eval'ing generated code and filesystem-access, Text-Template uses a  
set of regular-expressions to parse the template. Nor any intermediate code is generated nor any 
code is eval'ed. So TextTemplate should be more secure than Smarty or Twig by design.

TextTemplate supports infinite-nested loops and sequences.

## Install

* __Copy n Paste:__ Just Copy the contents of <https://github.com/dermatthes/text-template/blob/master/src/TextTemplate.php> to your project folder to
use TextTemplate. It's just one class.

* __Git externals:__ Clone this repository and add this as external to your project.

* __Download gzip'ed phar:__ If you like downloads we offer you a gzip'ed phar archive: <https://github.com/dermatthes/text-template/blob/master/_build/text-template.recent.phar.php.gz>

* __Download source tar:__ <https://raw.githubusercontent.com/dermatthes/text-template/master/_build/text-template.recent.src.tar.gz>

_TextTemplate uses Phing to build the phar-archives and gzip them. Just execute main-target in build.xml to build your own version_


## Basic Example
```php

// 1. Define the Template
$tplStr = <<<EOT
Hello World {= name }
{if name == "Matthias"}
Hallo {= name | capitalize }
{/if}
EOT;

// 2. Define the Data for the Template
$data = [
    "name" => "Matthias"
];

// 3. Parse
$tt = new TextTemplate($tplStr);
echo $tt->apply ($data);
```



## Value injection

Use the value Tag
```
{= varName}
```

To inject a value to the Code. Any variables will be ```htmlspecialchars()``` encoded by default. To
output the RAW content use the ```raw```-Filter: ```{=htmlCode|raw}```

To access array elements or objects use "." to access sub-elements:
 
 ```
 {= users.0.name}
 ```
 


### Adding Filters

You can add custom filters or overwrite own filters.

Adding a new Filter:

```php
$tt->addFilter ("currency", function ($input) {
    return number_format ($input, 2, ",", ".");
});
```

Use this filter inside your template

```
{= someVariable | currency }
```


### Replacing the default-Filter
By default and for security reason all values will be escaped using the "_DEFAULT_"-Filter. (except if
"raw" was selected within the filter section)

If you, for some reason, want to disable this functionality or change the escape function you can 
overwrite the _DEFAULT_-Filter:

```php
$tt->addFilter ("_DEFAULT_", function ($input) {
    return strip_tags ($input);
});
```

This example will replace the htmlspecialchars() escaper by the strip_tags() function.

## Loops

You can insert loops:

```
{for curName in names}
Current Name: {= curName}
{/for}
```

Inside each loop, there are to magick-values ```@index0``` (index starting with 0) and ```@index1``` for a
index starting with 1.

```
{for curName in names}
Line {= @index1 }: {= curName}
{/for}
```


## Conditions (if)

You can use if-conditions:

```
{if someVarName == "SomeValue"}
Hello World
{/if}
```

Limitation: Logical connections like OR / AND are not possible at the moment. Maybe in the future.




## Limitations

The logic-Expression-Parser won't handle logic connections (OR / AND) in conditions.

## Benchmark

Although the parser is build of pure regular-expressions, I tried to avoid too expensive constructions like
read ahead, etc.

And we got quite good results: 

| Template size | Parsing time[sec] |
|---------------|-------------------|
| 50kB          | 0.002             |
| 200kB         | 0.007             |



## About
Text-Template was written by Matthias Leuffen <http://leuffen.de>

<?php
/**
 *
 * The MIT License (MIT)
 *
 * Copyright (c) 2015 Matthias Leuffen, Aachen, Germany
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * For further information about me or my projects visit
 *
 * http://leuffen.de
 * https://github.com/dermatthes
 *
 */

namespace de\leuffen\text_template;

class TextTemplate {

    const VERSION = "1.0.1";


    private $mTemplateText;
    private $mFilter = [];
    private $mConf = [
        "varStartTag" => "{=",
        "varEndTag" => "}",
        "comStartTag" => "{",
        "comEndTag" => "}"
    ];

    public function __construct ($text="") {
        $this->mTemplateText = $text;
        $this->mFilter["_DEFAULT_"] = function ($input) { return htmlspecialchars($input); };

        // Raw is only a pseudo-filter. If it is not in the chain of filters, __DEFAULT__ will be appended to the filter
        $this->mFilter["raw"] = function ($input) { return $input; };
    }

    /**
     * Add a user-defined filter function to the list of available filters.
     *
     * A filter function must accept at least one parameter: input and return the resulting
     * value.
     *
     * Example:
     *
     * addFilter("currency", function (input) {
     *      return number_format ($input, 2, ",", ".");
     * });
     *
     * @param $filterName
     * @param callable $filterFn
     * @return $this
     */
    public function addFilter ($filterName, callable $filterFn) {
        $this->mFilter[$filterName] = $filterFn;
        return $this;
    }


    /**
     * Tag-Nesting is done by initially adding an index to both the opening and the
     * closing tag. (By the way some cleanup is done)
     *
     * Example
     *
     * {if xyz}
     * {/if}
     *
     * Becomes:
     *
     * {if0 xyz}
     * {/if0}
     *
     * This trick makes it possible to add tag nesting functionality
     *
     *
     * @param $input
     * @return mixed
     * @throws Exception
     */
    public function _replaceNestingLevels ($input) {
        $indexCounter = 0;
        $nestingIndex = [];

        $lines = explode("\n", $input);
        for ($li=0; $li < count ($lines); $li++) {
            $lines[$li] = preg_replace_callback('/\{(?!=)\s*(\/?)\s*([a-z]+)(.*?)\}/im',
                function ($matches) use (&$nestingIndex, &$indexCounter, &$li) {
                    $slash = $matches[1];
                    $tag = $matches[2];
                    $rest = $matches[3];
                    if ($slash == "") {
                        if ( ! isset ($nestingIndex[$tag]))
                            $nestingIndex[$tag] = [];
                        $nestingIndex[$tag][] = [$indexCounter, $li];
                        $out =  "{" . $tag . $indexCounter . rtrim($rest) . "}";
                        $indexCounter++;

                        return $out;
                    } else if ($slash == "/") {
                        if ( ! isset ($nestingIndex[$tag]))
                            throw new Exception("Line {$li}: Opening tag not found for closing tag: '{$matches[0]}'");
                        if (count ($nestingIndex[$tag]) == 0)
                            throw new Exception("Line {$li}: Nesting level does not match for closing tag: '{$matches[0]}'");
                        $curIndex = array_pop($nestingIndex[$tag]);
                        return "{/" . $tag . $curIndex[0] . "}";
                    } else {
                        throw new Exception("Line {$li}: This exception should not appear!");
                    }
                },
                $lines[$li]
            );

        }
        foreach ($nestingIndex as $tag => $curNestingIndex) {
            if (count ($curNestingIndex) > 0)
                throw new Exception("Unclosed tag '{$tag}' opened in line {$curNestingIndex[0][1]} ");
        }
        return implode ("\n", $lines);
    }



    private function _getValueByName ($context, $name, $softFail=TRUE) {
        $dd = explode (".", $name);
        $value = $context;
        $cur = "";
        foreach ($dd as $cur) {
            if (is_array($value)) {
                if ( ! isset ( $value[$cur] )) {
                    $value = NULL;
                } else {
                    $value = $value[$cur];
                }

            } else {
                if (is_object($value)) {
                    if ( ! isset ( $value->$cur )) {
                        $value = NULL;
                    } else {
                        $value = $value->$cur;
                    }
                } else {
                    if ( ! $softFail) {
                        throw new Exception("ParsingError: Can't parse element: '{$name}' Error on subelement: '$cur'");
                    }
                    $value = NULL;
                }
            }
        }
        if (is_object($value) && ! method_exists($value, "__toString"))
            $value = "##ERR:OBJECT_IN_TEXT:[{$name}]ON[{$cur}]:" . gettype($value) . "###";

        return $value;
    }



    private function _parseValueOfTags ($context, $block, $softFail=TRUE) {
        $result = preg_replace_callback ("/\\{=(.+?)\\}/im",
            function ($_matches) use ($softFail, $context) {
                $match = $_matches[1];

                $chain = explode("|", $match);
                for ($i=0; $i<count ($chain); $i++)
                    $chain[$i] = trim ($chain[$i]);

                if ( ! in_array("raw", $chain))
                    $chain[] = "_DEFAULT_";

                $varName = trim (array_shift($chain));
                $value = $this->_getValueByName($context, $varName, $softFail);

                foreach ($chain as $curName) {
                    if ( ! isset ($this->mFilter[$curName]))
                        throw new Exception("Filter '$curName' not defined");
                    $fn = $this->mFilter[$curName];
                    $value = $fn($value);
                }

                return $value;
            }, $block);
        return $result;
    }



    private function _runFor ($context, $content, $cmdParam, $softFail=TRUE) {
        if ( ! preg_match ('/([a-z0-9\.\_]+) in ([a-z0-9\.\_]+)/i', $cmdParam, $matches)) {

        }
        $iterateOverName = $matches[2];
        $localName = $matches[1];

        $repeatVal = $this->_getValueByName($context, $iterateOverName, $softFail);


        if ( ! is_array($repeatVal))
            return "";
        $index = 0;
        $result = "";
        foreach ($repeatVal as $key => $curVal) {
            $context[$localName] = $curVal;
            $context["@key"] = $key;
            $context["@index0"] = $index;
            $context["@index1"] = $index+1;
            $curContent = $this->_parseBlock($context, $content, $softFail);
            $curContent = $this->_parseValueOfTags($context, $curContent, $softFail);

            $result .= $curContent;
            $index++;
        }
        return $result;
    }


    private function _getItemValue ($compName, $context) {
        if (preg_match ('/^("|\')(.*?)\1$/i', $compName, $matches))
            return $matches[2]; // string Value
        if (is_numeric($compName))
            return ($compName);
        if (strtoupper($compName) == "FALSE")
            return FALSE;
        if (strtoupper($compName) == "TRUE")
            return TRUE;
        if (strtoupper($compName) == "NULL")
            return NULL;
        return $this->_getValueByName($context, $compName);
    }


    private function _runIf ($context, $content, $cmdParam, $softFail=TRUE) {
        //echo $cmdParam;
        if ( ! preg_match('/([\"\']?.*?[\"\']?)\s*(==|<|>|!=)\s*([\"\']?.*[\"\']?)/i', $cmdParam, $matches))
            return "!! Invalid command sequence: '$cmdParam' !!";

        //print_r ($matches);

        $comp1 = $this->_getItemValue(trim ($matches[1]), $context);
        $comp2 = $this->_getItemValue(trim ($matches[3]), $context);

        //decho $comp1 . $comp2;

        $doIf = FALSE;
        switch ($matches[2]) {
            case "==":
                $doIf = ($comp1 == $comp2);
                break;
            case "!=":
                $doIf = ($comp1 != $comp2);
                break;
            case "<":
                $doIf = ($comp1 < $comp2);
                break;
            case ">":
                $doIf = ($comp1 > $comp2);
                break;
        }

        if ( ! $doIf)
            return "";

        $content = $this->_parseBlock($context, $content, $softFail);
        $content = $this->_parseValueOfTags($context, $content, $softFail);
        return $content;

    }


    private function _parseBlock ($context, $block, $softFail=TRUE) {
        // (?!\{): Lookahead Regex: Don't touch double {{
        $result = preg_replace_callback('/\n?\{(?!=)(([a-z]+)[0-9]+)(.*?)\}(.*?)\n?\{\/\1\}/ism',
            function ($matches) use ($context, $softFail) {
                $command = $matches[2];
                $cmdParam = $matches[3];
                $content = $matches[4];

                switch ($command) {
                    case "for":
                        return $this->_runFor($context, $content, $cmdParam, $softFail);

                    case "if":
                        return $this->_runIf ($context, $content, $cmdParam, $softFail);

                    default:
                        return "!! Invalid command: '$command' !!";
                }
            }, $block);
        return $result;
    }


    /**
     * @param $template
     * @return $this
     */
    public function loadTemplate ($template) {
        $this->mTemplateText = $template;
        return $this;
    }


    /**
     * Parse Tokens in Text (Search for $(name.subname.subname)) of
     *
     *
     * @return string
     */
    public function apply ($params, $softFail=TRUE) {
        $text = $this->mTemplateText;

        $context = $params;

        $text = $this->_replaceNestingLevels($text);

        $text = $this->_parseBlock($context, $text, $softFail);
        $result = $this->_parseValueOfTags($context, $text, $softFail);

        return $result;
    }


}The MIT License (MIT)

Copyright (c) 2015 Matthias Leuffen, Aachen, Germany

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Zź/��ጛ�!y@X;c��   GBMB